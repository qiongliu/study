;(function(){

	function Slider () {
		console.log('slider');
	}

	new Slider();
	
})();